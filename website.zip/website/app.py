from flask import Flask, render_template, url_for, request, redirect, flash
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # 用于闪现消息

# 首页
@app.route("/")
def index():
    return render_template("index.html")

# 团队页面
@app.route("/team")
def team():
    return render_template("team.html")
# 在校职工页面
@app.route("/faculty")
def faculty():
    return render_template("faculty.html")

# 在读研究生页面
@app.route("/gradstudents")
def gradstudents():
    return render_template("gradstudents.html")

# 毕业研究生页面
@app.route("/alumni")
def alumni():
    return render_template("alumni.html")
# 研究页面
@app.route("/research")
def research():
    return render_template("research.html")

# 新闻页面
@app.route("/news")
def news():
    return render_template("news.html")

# 联系页面
@app.route("/contact")
def contact():
    return render_template("contact.html")

# 友情链接页面
@app.route("/friends")
def friends():
    return render_template("friends.html")

# 研究成果页面
@app.route("/get")
def get():
    return render_template("get.html")

# 留言表单提交处理
@app.route("/submit_contact", methods=["POST"])
def submit_contact():
    # 获取表单数据
    name = request.form.get("name")
    email = request.form.get("email")
    message = request.form.get("message")

    # 确保保存目录存在
    save_directory = "saved_messages"
    if not os.path.exists(save_directory):
        os.makedirs(save_directory)

    # 生成文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_name = f"{save_directory}/{timestamp}_{name}.txt"

    # 保存留言内容到文件
    with open(file_name, "w", encoding="utf-8") as file:
        file.write(f"姓名: {name}\n")
        file.write(f"邮箱: {email}\n")
        file.write(f"留言内容:\n{message}\n")
        file.write(f"提交时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    # 闪现消息
    flash("您的留言已成功提交！", "success")
    return redirect(url_for("contact"))

if __name__ == "__main__":
    app.run(debug=True)